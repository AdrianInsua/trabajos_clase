#!/usr/bin/python
# -*- coding: utf-8 -*-

from gi.repository import Gtk, GdkPixbuf
import os
import urllib2
import locale
import gettext

locale.setlocale(locale.LC_ALL,'es_ES.UTF-8')
LOCALE_DIR = os.path.join(os.path.dirname(__file__), "./locale")
locale.textdomain('app')
locale.bindtextdomain('app', LOCALE_DIR)
gettext.bindtextdomain('app',LOCALE_DIR)
gettext.textdomain('app')

_ = gettext.gettext

class VistaPrincipal:
	"""Pantalla principal de la aplicacion"""
	def __init__(self):
		builder = Gtk.Builder()
		builder.add_from_file("ppal.glade")
		self.window = builder.get_object("ppal")
		
		#enlazamos los objetos del menu
		self.addM = builder.get_object("nuevoMenu")
		self.verM = builder.get_object("menuVer")
		self.salirM = builder.get_object("salirMenu")
		self.editarM = builder.get_object("editarMenu")
		self.eliminarM = builder.get_object("eliminarMenu")
		self.aboutM = builder.get_object("aboutMenu")
		
		#enlazamos los objetos del toolbar
		self.add = builder.get_object("toolAdd")
		self.edit = builder.get_object("toolEditar")
		self.ver = builder.get_object("toolVer")
		self.eliminar = builder.get_object("toolDel")
		self.buttonLO = builder.get_object("toolLO")
		self.labelTool = builder.get_object("labelSesion")
		
		#creamos la lista
		self.tree = builder.get_object("treeview1")
		self.lista = Gtk.ListStore(int,str,int)
		self.tree.set_model(self.lista) ##modelo para la vista - 3 columnas, 2 visibles (col1,col2) 1 invisible(col0)
		self.tree.set_hexpand(True)
		renderer = Gtk.CellRendererText()
		column = Gtk.TreeViewColumn("Titulo", renderer, text = 1)
		self.tree.append_column(column)
		column = Gtk.TreeViewColumn("Año", renderer, text = 2)
		self.tree.append_column(column)
		
		#Dialogos de elminación
		self.elim=builder.get_object("elimDialog")
		self.elimTrue=builder.get_object("elimTrueDialog")
		
		#enlazamos los dialogos
		self.errLog = builder.get_object("dialogErrLog")
		self.errConn = builder.get_object("dialogErrConn")
		self.errUser = builder.get_object("dialogErrModUser")
		
		self.window.show_all()
		return

	def cerrar(self):
		self.window.destroy()
		return
		
	def vaciarLista(self):
		self.lista.clear()
	
	def ponerDatosLista(self, data):
		"""for data in data['data']:
			self.lista.append([data['title'],data['year']])"""
		iter = 0
		modelo = self.lista
		modelo.clear()
		for data in data['data']:	
			iterador = modelo.insert(iter) # el iterador es el objeto que contiene todos los valores de una fila concretaWS
			modelo.set_value(iterador,0, data['id'])
			modelo.set_value(iterador,1, data['title'])
			modelo.set_value(iterador,2, data['year'])
			iter = iter + 1
			
	def getSelected(self):
		#devuelve el id(col0) de la fila seleccionada
		seleccion, iterador = self.tree.get_selection().get_selected()
		return seleccion.get_value(iterador, 0)

	def setUserlabel(self, user):
		#escribe la bienvenida al usuario en el label de la toolbar
		self.labelTool.set_label(_("Bienvenido, ")+user)
		return
		
	def setLabelLog(self, text):
		self.buttonLO.set_label(text)
		return
		
	def dialogoAbout(self):
		#abre el dialogo about del menu
		self.about.run()
		self.about.hide()
		
	def mensajeAlert(self, flag): #dialogo de error para fallo de login
		#con hide se arregla el error que daba al fallar dos veces
		if flag == 0:
			dialog = self.errLog
			dialog.run()		
			dialog.hide()
		if flag == 1:
			dialog = self.errConn
			dialog.run()
			dialog.destroy()
			Gtk.main_quit()
		if flag == 2:
			dialog = self.elimTrue
			dialog.run()
			dialog.hide()
		if flag == 3:
			dialog = self.elim
			response = dialog.run()
			dialog.hide()
			return response
		if flag == 4:
			dialog = self.errUser
			dialog.run()
			dialog.hide()
		return
				
	pass
	
class VistaModificarPelicula:
	def __init__(self, datos):
		builder = Gtk.Builder()
		builder.add_from_file("addpeli.glade")
		self.window = builder.get_object("addDatos")
		self.titulo = builder.get_object("entryTit")
		self.year = builder.get_object("entryY")
		self.url = builder.get_object("entryUrl")
		self.cat = builder.get_object("entryCat")
		self.descview = builder.get_object("textview1")	
		self.descbuff = builder.get_object("textbufferDesc")
		self.buttonOk = builder.get_object("buttonOk")
		self.buttonCancel = builder.get_object("buttonCanc")
		self.setEntrys(datos)
		self.window.show_all()
		
	def getDatos(self):
		return self.titulo.get_text(), self.descbuff.get_text(self.descbuff.get_start_iter(),self.descbuff.get_end_iter(),False), self.url.get_text(), self.year.get_text(),self.cat.get_text()
		
	def cerrar(self):
		self.window.destroy()		
				
	def setEntrys(self,data):
		#ponemos los datos extraidos de la respuesta json
		self.url.set_text(data['data']['url_image'])
		self.titulo.set_text(data['data']['title'])
		self.year.set_text(str(data['data']['year']))
		self.cat.set_text(data['data']['category'])
		self.descbuff.set_text(data['data']['synopsis'])
		
	pass
	
class VistaLogin:
	"""representacion grafica de la aplicacion"""
	def __init__(self):
		builder = Gtk.Builder()
		builder.add_from_file("login.glade")
		self.window = builder.get_object("login")
		self.user = builder.get_object("user")
		self.contra = builder.get_object("contra")
		self.buttonEnt = builder.get_object("buttonEnt")
		self.buttonCanc = builder.get_object("buttonCanc")
		#Enlazamos los dialogbox de la aplicacion
		self.errLog = builder.get_object("dialogErrLog")
		self.errConn = builder.get_object("dialogErrConn")
		self.errLogRep = builder.get_object("dialogErrLogRep")
		self.window.show_all()
		
		#ponemos los datos de prueba
		self.user.set_text("adrian.insua")
		self.contra.set_text("Q5VLVdLQ")
		return
		
	def set_labEnt(self, text):
		self.buttonEnt.set_label(text)
		
	def cerrar(self):
		self.window.destroy()
		return
		
	def getUser(self):
		return self.user.get_text()
		
	def getPass(self):
		return self.contra.get_text()
		
	def mensajeAlert(self, flag): #dialogo de error para fallo de login
		#con hide se arregla el error que daba al fallar dos veces
		if flag == 0:
			dialog = self.errLog
			dialog.run()		
			dialog.hide()
		if flag == 1:
			dialog = self.errConn
			dialog.run()
			dialog.destroy()
			Gtk.main_quit()
		if flag == 2:
			dialog = self.errLogRep
			dialog.run()
			dialog.hide()
		return
	pass
	
class VistaVerPelicula:
	
	def __init__(self, datos):
		builder = Gtk.Builder()
		builder.add_from_file("verpeli.glade")
		self.window = builder.get_object("verDatos")
		self.labelD = builder.get_object("labelD")
		self.labelD.set_line_wrap(True)
		self.labelT = builder.get_object("labelT")
		self.labelY = builder.get_object("labelY")
		self.labelABU = builder.get_object("labelAB")
		self.labelCat = builder.get_object("labelCat")
		self.image = builder.get_object("imagen")
		self.botonera = builder.get_object("box7")#botonera para los botones editar eliminar si la pelicula está subida por ti
		self.ponerDatos(datos)
		self.window.show_all()
		return
		
	def ponerDatos(self, data):
		#ponemos los datos extraidos de la respuesta json
		self.labelT.set_label(data['data']['title'])
		self.labelD.set_label(data['data']['synopsis'])
		self.labelY.set_label(str(data['data']['year']))
		self.labelABU.set_label(data['data']['username'])
		self.labelCat.set_label(data['data']['category'])
		"""en el siguiente try se intenta cargar la imagen dada por el
		json, en caso de no ser posible se carga una predeterminada"""
		try:
			foto ="foto"
			url = data['data']['url_image']
			response = urllib2.urlopen(url)
			with open(foto, 'wb') as img:
				img.write(response.read())
		except Exception, ex:
			foto ="fotofallo"
		"""la imagen se guarda en un objeto pixbuf ya que asi facilita el
		reescalado"""
		pixbuf = GdkPixbuf.Pixbuf.new_from_file(foto)
		scaled_buf = pixbuf.scale_simple(356, 420, GdkPixbuf.InterpType.BILINEAR)
		self.image.set_from_pixbuf(scaled_buf)
		return
		
	def cerrar(self):
		self.window.destroy()
		
	pass

class VistaAddPeli:
	
	def __init__(self):
		builder = Gtk.Builder()
		builder.add_from_file("addpeli.glade")
		self.window = builder.get_object("addDatos")
		self.titulo = builder.get_object("entryTit")
		self.year = builder.get_object("entryY")
		self.url = builder.get_object("entryUrl")
		self.cat = builder.get_object("entryCat")
		self.descview = builder.get_object("textview1")	
		self.descbuff = builder.get_object("textbufferDesc")
		self.buttonOk = builder.get_object("buttonOk")
		self.buttonCanc = builder.get_object("buttonCanc")
		
		self.window.show_all()
	
	def getDatos(self):
		return self.titulo.get_text(), self.descbuff.get_text(self.descbuff.get_start_iter(),self.descbuff.get_end_iter(),False), self.url.get_text(), self.year.get_text(),self.cat.get_text()
		
	def cerrar(self):
		self.window.destroy()
	
	pass
