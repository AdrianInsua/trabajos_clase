#!/usr/bin/python
# -*- coding: utf-8 -*-
from gi.repository import Gtk

from modelo import Modelo
from vistas import VistaLogin
from controles import ControlLogin

if __name__ == "__main__":
	try:
		m = Modelo()
		v = VistaLogin()
		c = ControlLogin(m, v, False, None)
		c.main()
	except:
		m.logout()
		Gtk.main_quit()
	pass

