#!/usr/bin/python
# -*- coding: utf-8 -*-
import httplib, urllib
import json, os

from gi.repository import Gtk, GObject
import threading

##usamos este timeout ya que aunque se establezca la conexion
##puede ser que al hacer request se quede colagado
##es el caso de dejar el puerto 5000 colgado con nc -lk 50001
import socket

timeout = 4
socket.setdefaulttimeout(timeout)

_FALLO = 0
_YACONN = 2
_CONN = 1
_FALLOCONN = 3
_ERRLOG = 4
_ERRUSER = 5

class Modelo:
	"""esta clase contiene el modelo de operaciones del sistema"""
	def __init__(self):
		self.user = ''
		self.cookie = ''
		self.conexion = httplib.HTTPConnection('ipm-movie-database.herokuapp.com')
		
	def establecerConexion(self, header, param, tipo, pag):
		#Función para establecer la conexión con el servidor
		try:
			if header != None:
				self.conexion.request(tipo, pag, param, header)
			else:
				self.conexion.request(tipo,pag)
			respuesta = self.conexion.getresponse()
			return respuesta
		except Exception, ex:
			print ex
			return _FALLO
		
	"""-------SETTERS-------"""
	def setCookie(self, cookie, user):
		#Establecemos el archivo de las cookies
		try:
			fcookie = open("cookies"+user+".txt", "w")
			fcookie.write(cookie)
			fcookie.close()
		except:
			print "fallo al establecer cookie"
			return _FALLO
			
			
	"""--------GETTERS----------"""
	def getCookie(self, user):
		#Obtenemos las cookies del archivo de texto
		try:
			fcookies = open("cookies"+user+".txt")
			cookies = fcookies.read()
			fcookies.close()
			return cookies
		except:
			return ""
			
	def getUser(self):
		#Obtenemos el usuario
		return self.user
			
	"""---------FUNCIONES DE MODELO---------"""
	def comprobarSesion(self, user):
		#funcion para comprobar el estado de la sesion
		#si el resultado es success el usuario ya se ha conectado al server
		try:
			cookies = self.getCookie(user)
			headers = {"Cookie":cookies}
			respuesta = self.establecerConexion(headers, None, "GET", "/session")
			if respuesta != 0:
				estado = respuesta.read()
				d = json.loads(estado)
				return d['result']
			else:
				return _FALLO
		except:
			print "error de conexión con el servidor"
			return _FALLOCONN
			
	def login(self, user, passwd):
		#funcion login
		parametros = urllib.urlencode({'username':user,'passwd':passwd})
		cabeceras = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
		try:
			estadoSesion = self.comprobarSesion(user)
			if estadoSesion == 'success' or self.user != '':
				return _YACONN
			respuesta = self.establecerConexion(cabeceras, parametros, "POST", "/login")
			if respuesta != 0:
				estado = respuesta.read()
				#se interpreta la respuesta dada en json para ver si es correcta
				d = json.loads(estado)
				if d['result']== 'success':
					self.user = user
					self.setCookie(respuesta.getheader('set-cookie'),user)
					return _CONN
				return _ERRLOG
			else:
				return _FALLO
		except Exception, ex:
			print ex
			return _FALLOCONN
			
	def logout(self):
		try:
			if self.user != '':
				estadoSesion = self.comprobarSesion(self.user)
				if estadoSesion != 'success':
					return _YACONN
				cookies = self.getCookie(self.user)
				headers = {"Cookie": cookies}
				respuesta = self.establecerConexion(headers, None, "GET", "/logout")
				if respuesta != 0:
					estado = respuesta.read()
					#se interpreta la respuesta dada en json para ver si es correcta
					d = json.loads(estado)
					if d['result']== 'success':
						print "Logout completo"
						os.getcwd()
						os.remove("cookies"+self.user+".txt")
						self.user = ''
						self.conexion.close()
						return _CONN
					return _FALLO
			else:
				print "Logout completo"
				return _CONN
		except Exception, ex:
			print("Se ha producido un error en la conexion");
			return _FALLOCONN
		return
		
		
	def eliminar(self, movie):
		try: #confirmar usuario autentificar
			estadoSesion = self.comprobarSesion(self.user)
			if estadoSesion != 'success':
				return _FALLO
			cookies = self.getCookie(self.user)
			headers = {"Cookie": cookies}
			respuesta = self.establecerConexion(headers, None, "DELETE", "/movies/"+str(movie))
			if respuesta != 0:
				info = respuesta.read()
				d = json.loads(info)
				if d['result'] == 'success':
					return _CONN
				else:
					return _ERRUSER
		except Exception, ex:
			print ex
			return _FALLOCONN
		return
	
	
	def getMovies(self):
		try:
			estadoSesion = self.comprobarSesion(self.user)
			if estadoSesion != 'success':
				return _FALLO
			respuesta = self.establecerConexion(None,None,"GET","/movies")
			if respuesta != 0:
				estado = respuesta.read()
				d = json.loads(estado)
				return d
		except Exception, ex:
			print ex
			return _FALLOCONN
			
	def getMovie(self, movie):
		try:
			estadoSesion = self.comprobarSesion(self.user)
			if estadoSesion != 'success':
				return _FALLO
			cookies = self.getCookie(self.user)
			headers = {"Cookie": cookies}
			respuesta = self.establecerConexion(headers, None, "GET", "/movies/"+str(movie))
			if respuesta != 0:
				info = respuesta.read()
				#se interpreta el json para enviar los datos a la funcion
				d = json.loads(info)
				return d
		except Exception, ex:
			print("Se ha producido un error en la conexion");
			return _FALLOCONN
		return
		
	def getMovieRestrict(self, movie):
		try:
			estadoSesion = self.comprobarSesion(self.user)
			if estadoSesion != 'success':
				return _FALLO
			cookies = self.getCookie(self.user)
			headers = {"Cookie": cookies}
			respuesta = self.establecerConexion(headers, None, "GET", "/movies/"+str(movie))
			if respuesta != 0:
				info = respuesta.read()
				#se interpreta el json para enviar los datos a la funcion
				d = json.loads(info)
				if (d['data']['username'] != self.user):
					return _ERRUSER
				else:
					return d
		except Exception, ex:
			print("Se ha producido un error en la conexion");
			return _FALLOCONN
		return

	def updateMovie(self, movie, t, s, u, y, c):
		try:
			estadoSesion = self.comprobarSesion(self.user)
			if estadoSesion != 'success':
				return _FALLO
			cookies = self.getCookie(self.user)
			headers={"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain","Cookie":cookies}
			parametros = urllib.urlencode({'title':t,'synopsis':s, 'category': c, 'year':y, 'url_image':u })
			respuesta = self.establecerConexion(headers, parametros, "PUT", "/movies/"+str(movie))
			if respuesta != 0:
				info = respuesta.read()
				#se interpreta el json para enviar los datos a la funcion
				d = json.loads(info)
				if (d['result'] != 'success'):
					return _ERROR
				else:
					return _CONN
		except Exception, ex:
			print ex;
			return _FALLOCONN
		return	
		
	def pushMovie(self, t, s, u, y, c):
		try:
			estadoSesion = self.comprobarSesion(self.user)
			if estadoSesion != 'success':
				return _FALLO
			cookies = self.getCookie(self.user)
			headers = {"Cookie": cookies}
			parametros = urllib.urlencode({'title':t,'synopsis':s, 'url_image':u, 'year':str(y), 'category': c})
			respuesta = self.establecerConexion(headers, parametros, "POST", "/movies")
			if respuesta != 0:
				info = respuesta.read()
				#se interpreta el json para enviar los datos a la funcion
				d = json.loads(info)
		except Exception, ex:
			print("Se ha producido un error en la conexion");
			return _FALLOCONN
