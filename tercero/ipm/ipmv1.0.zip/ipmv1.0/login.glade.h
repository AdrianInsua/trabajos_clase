char *s = N_("<b>Error de conexion</b>");
char *s = N_("No se ha podido alcanzar el servidor");
char *s = N_("<b>Error de login</b>");
char *s = N_("Usuario o contraseña incorrectos");
char *s = N_("Usuario ya conectado");
char *s = N_("IPM MOVIE DATABASE");
char *s = N_("Bienvenidos a la aplicacion de gestión de peliculas de IPM");
/* sdf */
char *s = C_("dfsk&#9;s&#9;&#9;&#9;", "Usuario :");
char *s = N_("Contraseña :");
char *s = N_("Cancelar");
char *s = N_("Entrar");
