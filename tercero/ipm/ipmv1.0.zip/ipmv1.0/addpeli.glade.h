char *s = N_("Peliculas BD - Ver pelicula");
char *s = N_("Titulo : ");
char *s = N_("Año : ");
char *s = N_("Url img :");
char *s = N_(" Categ. : ");
char *s = N_("Descripción");
char *s = N_("Aceptar");
char *s = N_("Cancelar");
