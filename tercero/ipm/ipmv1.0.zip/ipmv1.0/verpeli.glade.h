char *s = N_("Peliculas BD - Ver pelicula");
char *s = N_("Titulo : ");
char *s = N_("Año : ");
char *s = N_("label");
char *s = N_("Cat. : ");
char *s = N_("Descripción");
char *s = N_("Añadido por : ");
