#!/usr/bin/python
# -*- coding: utf-8 -*-

from vistas import VistaLogin, VistaPrincipal, VistaVerPelicula, VistaAddPeli , VistaModificarPelicula
from gi.repository import Gtk, GObject
import os, threading, time
import gettext

_ = gettext.gettext

"""---------flags control---------------"""
_FALLO = 0
_YACONN = 2
_CONN = 1
_FALLOCONN = 3
_ERRLOG = 4
_ERRUSER = 5

"""----------variables multithread------"""
#creamos un lock de modelo para evitar que mientras se realiza un ver detalle
#de pelicula se pueda relizar en paralelo un logout y falle
model = threading.Lock()


"""-----------clases threads---------------"""

class logThread(threading.Thread):
	#thread login
	def __init__(self, cont, model, user, passwd):
		threading.Thread.__init__(self)
		self.cont = cont
		self.model = model
		self.user = user
		self.passwd = passwd
		
	def run(self):
		#el thread bloque el login
		#(nos interesa que acabe uno antes de empezar el siguiente)
		model.acquire() #bloqueo para multi login
		acceso = self.model.login(self.user, self.passwd)
		model.release()
		GObject.idle_add(self.cont.logOk,acceso) ## llamada a principal
		return
		
class logOutThread(threading.Thread):
	#thread logout
	def __init__(self, model, cont, tipo):
		threading.Thread.__init__(self)
		self.model = model
		self.cont = cont
		self.tipo = tipo
		
	def run(self):
		#bloqueamos el thread para reliazar el logout
		model.acquire()
		retorno = self.model.logout()
		model.release()
		if retorno == _CONN:
			if self.tipo == 1:
				GObject.idle_add(self.cont.quitting)
		else:
			GObject.idle_add(self.cont.mensajes, retorno)

class cargarPelisThread(threading.Thread):
	#thread carga lista pelis
	def __init__(self, model, cont):
		threading.Thread.__init__(self)
		self.model = model
		self.cont = cont
	
	def run(self):
		model.acquire()
		data = self.model.getMovies()
		model.release()
		if data == _FALLO or data == _FALLOCONN:
			GObject.idle_add(self.cont.mensajes, data)
		else:
			GObject.idle_add(self.cont.cargarListaData, data)
		
class verPeliThread(threading.Thread):
	#thread ver peli
	def __init__(self, peli, model, cont):
		threading.Thread.__init__(self)
		self.peli = peli
		self.cont = cont
		self.model = model
		
	def run(self):
		#-Se llama a la funcion getMovie(id movie) del modelo
		#-Se presentan sus datos por pantalla
		
		##llamada a modelo para obtener datos
		model.acquire()
		data = self.model.getMovie(self.peli)
		model.release()
		if data == _FALLO or data == _FALLOCONN:
			GObject.idle_add(self.cont.mensajes, data)
		else:
			##llamada al controlador para colocar los datos
			GObject.idle_add(self.cont.verData, data)
			
class addPeliThread(threading.Thread):
	#thread para añadir peliculas
	def __init__(self, model, cont, t,s,u,y,c):
		threading.Thread.__init__(self)
		self.model = model
		self.cont = cont
		self.t = t
		self.s = s
		self.u = u
		self.y = y
		self.c = c
		
	def run(self):
		model.acquire()
		retorno = self.model.pushMovie(self.t,self.s,self.u,self.y,self.c)
		model.release()
		GObject.idle_add(self.cont.subirOk, retorno)
		
class updatePeliThread(threading.Thread):
	#thread para añadir peliculas
	def __init__(self, model, movie, cont, t,s,u,y,c):
		threading.Thread.__init__(self)
		self.model = model
		self.cont = cont
		self.movie = movie
		self.t = t
		self.s = s
		self.u = u
		self.y = y
		self.c = c
		
	def run(self):
		model.acquire()
		retorno = self.model.updateMovie(self.movie, self.t,self.s,self.u,self.y,self.c)
		model.release()
		GObject.idle_add(self.cont.subirOk, retorno)
		

	
class modificarPeliThread(threading.Thread):
	#thread ver peli
	def __init__(self, peli, model, cont):
		threading.Thread.__init__(self)
		self.peli = peli
		self.cont = cont
		self.model = model
		
	def run(self):
		#-Se llama a la funcion getMovie(id movie) del modelo
		#-Se presentan sus datos por pantalla
		
		##llamada a modelo para obtener datos
		model.acquire()
		data = self.model.getMovieRestrict(self.peli)
		model.release()
		if data == _FALLO or data == _FALLOCONN or data == _ERRUSER:
			GObject.idle_add(self.cont.mensajes, data)
		else:
			##llamada al controlador para colocar los datos
			GObject.idle_add(self.cont.modificarPeli, data, self.peli)
	
class elimPeliThread(threading.Thread):
	#thread para eliminar
	def __init__(self, peli, model, cont):
		threading.Thread.__init__(self)
		self.peli = peli
		self.cont = cont
		self.model = model
		
	def run(self):
		model.acquire()
		data = self.model.eliminar(self.peli)
		model.release()
		if data == _CONN:
			GObject.idle_add(self.cont.cargarListaElim)
		else:
			GObject.idle_add(self.cont.mensajes, data)




"""---------------funciones controlador--------------"""

class ControlLogin:
	"""Control para la pantalla de login"""
	
	"""------------FUNCIONES MOD. MODELO------------"""
	"""---llama a thread----------------------------"""
	
	def entrar(self, widget):
		#Funcion thread de conexion
		self.view.set_labEnt(_("Conectando..."))
		#t = threading.Thread(target=self.logThread(self.view.getUser(), self.view.getPass())).start()
		t = logThread(self,self.model, self.view.getUser(), self.view.getPass())
		t.start()
		
	def logOk(self, acceso):
		
		if acceso == _CONN:
			#cambio de escenario
			self.view.cerrar()
			if self.llamada == False:
				ControlPpal(self.model, VistaPrincipal())
			else:
				self.ppal.view.setLabelLog("Logout")
				self.ppal.view.buttonLO.connect("clicked", self.ppal.logOut)
				self.ppal.cargarLista()
		elif acceso == _ERRLOG:
			#muestra dialogo de error
			self.view.mensajeAlert(0)
		elif acceso == _YACONN:
			self.view.mensajeAlert(2)
		elif acceso == _FALLOCONN or acceso == _FALLO:
			self.view.mensajeAlert(1)
			
	def mensajes(self, acceso):
		if acceso == _ERRLOG:
			#muestra dialogo de error
			self.view.mensajeAlert(0)
		elif acceso == _YACONN:
			self.view.mensajeAlert(2)
		elif acceso == _FALLOCONN or acceso == _FALLO:
			self.view.mensajeAlert(1)
	
	"""INICIALIZACION"""
	def __init__(self, model, view, llamada, ppal):
		#la variable llamada almacena si se abre la ventana desde boton o es la ppal
		#llamada = False -> ppal llamada = True -> desde boton
		self.model = model
		self.view = view
		self.llamada = llamada
		self.ppal = ppal
		self.view.window.connect("delete-event", self.on_delete_event)
		self.view.buttonCanc.connect("clicked", self.on_close_action)
		self.view.contra.connect("activate", self.entrar)
		self.view.buttonEnt.connect("clicked", self.entrar)
	
	def main(self):
		Gtk.main()
		
	"""------------------FUNCIONES DE CIERRE----------------"""
	def on_close_action(self, button):
		if self.llamada:
			self.view.cerrar()		
		else: 
			t = logOutThread(self.model, self, 1)
			t.start()
			
	def quitting(self):
		Gtk.main_quit()
		
	def on_delete_event(self, window, event):
		if self.llamada:
			self.view.cerrar()		
		else: 
			t = logOutThread(self.model, self, 1)
			t.start()
	pass
	
class ControlPpal:
	"""control del ppal sin log"""
	def __init__(self, model, view):
		self.model = model
		self.view = view
		self.view.window.connect("delete-event", self.on_delete_event)
		self.view.salirM.connect("activate", self.on_cancel_event)
		self.view.verM.connect("activate", self.ver)
		self.view.ver.connect("clicked", self.ver)
		self.view.add.connect("clicked", self.add)
		self.view.addM.connect("activate", self.add)
		self.view.editarM.connect("activate", self.editar)
		self.view.edit.connect("clicked", self.editar)
		self.view.eliminarM.connect("activate", self.eliminar)
		self.view.eliminar.connect("clicked", self.eliminar)
		self.view.aboutM.connect("activate", self.about)
		self.view.buttonLO.connect("clicked", self.logOut)
		self.view.setUserlabel(self.model.getUser())
		self.cargarLista()
		
	"""--------FUNCIONES MOD. MODELO--------------"""
		
	def add(self, widget):
		#se abre la pantalla de añadir pelicula
		ControlAddPelicula(self.model, VistaAddPeli(), self)
		
	def editar(self, widget):
		#accion llamada por el boton de editar
		id = self.view.getSelected()
		t = modificarPeliThread(id, self.model, self)
		t.start()
		pass
		
	def eliminar(self, widget):
		#accion llamada por el boton de eliminar
		id=self.view.getSelected()
		response = self.view.mensajeAlert(3)
		if response == -8:
			t = elimPeliThread(id, self.model, self)
			t.start()
		pass
		
	def ver(self, widget):
		#se abre la pantalla de ver pelicula
		#id = fila seleccionada de la lista
		#data = datos obtenidos de la pelicula
		id = self.view.getSelected()
		t = verPeliThread(id, self.model, self)
		t.start()
		
	def verData(self, data):		
		ControlVerPelicula(self.model, VistaVerPelicula(data))
		
	def modificarPeli(self, data, id):
		ControlModificarPelicula(self.model, VistaModificarPelicula(data), self, id)
		
	def cargarLista(self):
		#carga los datos de la lista e thread
		t = cargarPelisThread(self.model, self)
		t.start()
		
	def cargarListaElim(self):
		self.view.mensajeAlert(2)
		#carga los datos de la lista e thread
		t = cargarPelisThread(self.model, self)
		t.start()
		
	def cargarListaData(self, data):
		#carga los datos en la lista de la pantalla principal
		self.view.ponerDatosLista(data)
		
	"""---------FUNCIONES TOOLBAR----------"""
		
	def log(self, widget):
		#se crea la vista de login en otra pantalla
		ControlLogin(self.model, VistaLogin(), True, self)
		
	def logOut(self, widget):
		#se realiza el logout de sesion
		t = logOutThread(self.model, self, 0)
		t.start()
		self.view.setLabelLog("login")
		self.view.setUserlabel("")
		self.view.vaciarLista()
		self.view.buttonLO.connect("clicked", self.log)
		
	def about(self, widget):
		#se abre la pantalla del about
		self.view.dialogoAbout()
		
	"""------FUNCION MUESTRA MENSAJES------"""
	def mensajes(self, acceso):
		if acceso == _FALLO:
			self.view.mensajeAlert(0)
		elif acceso == _FALLOCONN or acceso == _FALLO:
			self.model.logout()
			self.view.mensajeAlert(1)
		elif acceso == _CONN:
			self.view.mensajeAlert(2)
		elif acceso == _ERRUSER:
			self.view.mensajeAlert(4)
		
	"""------FUNCIONES DE SALIDA----------"""
		
	def on_delete_event(self, window, event): 
		#para salir se realiza tambien el logout de sesion
		t = logOutThread(self.model, self, 1)
		t.start()
	
	def on_close_event(self, window, event): 
		#para salir se realiza tambien el logout de sesion
		t = logOutThread(self.model, self, 1)
		t.start()
		
		
	def on_cancel_event(self, widget): 
		#para salir se realiza tambien el logout de sesion
		t = logOutThread(self.model, self, 1)
		t.start()
		
	def quitting(self):
		Gtk.main_quit()
		
	def main(self):
		Gtk.main()
		
	pass
	
class ControlVerPelicula:
	"""control para ver pelicula"""
	
			
	def on_close(self, window, event):
		self.view.cerrar()
	
	def __init__(self, model, view):
		self.model = model
		self.view = view
		self.view.window.connect("delete-event", self.on_close)
				
	pass

class ControlModificarPelicula:
	"""control para modificar pelicula"""
	
	def __init__(self, model, view, padre, movie):
		self.model = model
		self.view = view
		self.padre = padre
		self.peli = movie
		self.view.window.connect("delete-event", self.on_close)
		self.view.buttonCancel.connect("clicked", self.on_cancel)
		self.view.buttonOk.connect("clicked", self.cargarDatos)
		
	def cargarDatos(self, widget):
		t, s, u, y, c = self.view.getDatos()
		thread = updatePeliThread(self.model, self.peli, self, t,s,u,y,c)
		thread.start()
	
	def subirOk(self, resp):
		self.view.cerrar()
		if resp != _FALLO or resp != _FALLOCONN:
			self.padre.cargarLista()
		else:
			self.padre.mensajes(resp)
		
	def on_close(self, window, event):
		self.view.cerrar()
	
	def on_cancel(self, widget):
		self.view.cerrar()
				
	pass
	
class ControlAddPelicula:
	"""control para ver pelicula"""
	
	def __init__(self, model, view, padre):
		self.model = model
		self.view = view
		self.padre = padre
		self.view.window.connect("delete-event", self.on_close)
		self.view.buttonCanc.connect("clicked", self.on_cancel)
		self.view.buttonOk.connect("clicked", self.subir)
		
	def subir(self, widget):
		t, s, u, y, c = self.view.getDatos()
		thread = addPeliThread(self.model, self, t,s,u,y,c)
		thread.start()
	
	def subirOk(self, resp):
		self.view.cerrar()
		if resp != _FALLO or resp != _FALLOCONN:
			self.padre.cargarLista()
		else:
			self.padre.mensajes(resp)
		
	def on_close(self, window, event):
		self.view.cerrar()
	
	def on_cancel(self, widget):
		self.view.cerrar()
				
	pass
GObject.threads_init()
